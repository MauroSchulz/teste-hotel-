import { useState, type ReactNode } from "react";
import {
  DataProviderContext,
  type AppDataProvider,
  type ContactMessage,
} from "@/lib/data-provider";

const day = 86_400_000;
const ago = (d: number, h = 0) =>
  new Date(Date.now() - d * day - h * 3_600_000).toISOString();

const SEED: ContactMessage[] = [
  { id: "m1", name: "Eleanor Hughes", email: "eleanor.hughes@example.com", subject: "Valuation for my Dock Street flat", inquiry_type: "General Question", message: "Hello Mara, I'm thinking of selling my two-bedroom flat on Dock Street this spring. Could you come round for a valuation next week? Tuesday or Thursday afternoons suit me best.", status: "new", created_at: ago(0, 2) },
  { id: "m2", name: "Tom Okafor", email: "tom.okafor@example.com", subject: "Viewing the Harbour townhouse", inquiry_type: "General Question", message: "We saw the townhouse on Quay Lane online and would love to book a viewing this Saturday morning if possible. We're mortgage-approved.", status: "new", created_at: ago(0, 5) },
  { id: "m3", name: "Priya Shah", email: "priya@harbourlife.example", subject: "Feature in Harbour Life magazine", inquiry_type: "Press / Media", message: "I'm writing a piece on independent agents in the area and would love a short interview with you about the local market this year.", status: "new", created_at: ago(1, 1) },
  { id: "m4", name: "James Whitfield", email: "j.whitfield@example.com", subject: "Offer on Mill Road cottage", inquiry_type: "General Question", message: "Following our viewing yesterday, we'd like to discuss putting in an offer on the Mill Road cottage. Please call me when convenient.", status: "new", created_at: ago(1, 6) },
  { id: "m5", name: "Sofia Marin", email: "sofia.marin@example.com", subject: "Staging partnership", inquiry_type: "Collaboration", message: "I run a small home staging studio in Harbourside. I'd love to talk about working together on your upcoming listings.", status: "new", created_at: ago(2, 3) },
  { id: "m6", name: "David Chen", email: "david.chen@example.com", subject: "First-time buyer questions", inquiry_type: "General Question", message: "We're buying our first home and feel a bit lost. Do you offer a quick call to walk us through how offers and surveys work?", status: "read", created_at: ago(3, 2) },
  { id: "m7", name: "Hannah Brooks", email: "hannah.brooks@example.com", subject: "Selling after probate", inquiry_type: "Other", message: "My late mother's house on Elm Terrace needs to be sold once probate is finished. Could we talk about timing and what you'd need from me?", status: "read", created_at: ago(4, 4) },
  { id: "m8", name: "Marcus Bell", email: "marcus.bell@example.com", subject: "Is the Canal Wharf flat still available?", inquiry_type: "General Question", message: "Hi, just checking whether the Canal Wharf one-bed is still on the market and whether parking is included.", status: "read", created_at: ago(5, 1) },
  { id: "m9", name: "Aisha Rahman", email: "aisha.r@example.com", subject: "Rental vs selling advice", inquiry_type: "General Question", message: "I'm torn between letting out my flat or selling it. Would you be able to give an honest view on both options?", status: "read", created_at: ago(6, 3) },
  { id: "m10", name: "Oliver Grant", email: "oliver@grantphoto.example", subject: "Property photography", inquiry_type: "Collaboration", message: "I'm a local architectural photographer. Happy to shoot one listing for free so you can see my work.", status: "read", created_at: ago(8, 2) },
  { id: "m11", name: "Laura Fischer", email: "laura.fischer@example.com", subject: "Thank you!", inquiry_type: "Other", message: "Just wanted to say thank you for selling our house so quickly. The keys are handed over and we're settled in our new place.", status: "read", created_at: ago(10, 5) },
  { id: "m12", name: "Ben Taylor", email: "ben.taylor@example.com", subject: "Garden flat on Rope Walk", inquiry_type: "General Question", message: "Could you send the floor plan for the Rope Walk garden flat? Also curious about the service charge.", status: "new", created_at: ago(11, 1) },
  { id: "m13", name: "Grace Kim", email: "grace@coastalnews.example", subject: "Market comment request", inquiry_type: "Press / Media", message: "Would you provide a two-line comment on house prices in Harbourside for our Friday edition?", status: "read", created_at: ago(13, 2) },
  { id: "m14", name: "Samuel Ade", email: "samuel.ade@example.com", subject: "Downsizing in the autumn", inquiry_type: "General Question", message: "My wife and I are looking to downsize from our four-bed later this year. Can we arrange an initial chat?", status: "read", created_at: ago(15, 4) },
];

export function SeedDataProvider({ children }: { children: ReactNode }) {
  const [messages, setMessages] = useState<ContactMessage[]>(SEED);

  const provider: AppDataProvider = {
    useProfile: () => ({
      data: { id: "demo", full_name: "Mara Lindqvist" },
      isLoading: false,
    }),
    useCreateContactMessage: () => ({
      mutate: (input) =>
        setMessages((m) => [
          { ...input, id: crypto.randomUUID(), status: "new", created_at: new Date().toISOString() },
          ...m,
        ]),
      isPending: false,
    }),
    useMessages: (filters) => ({
      data: messages.filter((m) =>
        filters.tab === "all" ? m.status !== "archived" : m.status === filters.tab,
      ),
      isLoading: false,
    }),
    useUpdateMessageStatus: () => ({
      mutate: ({ id, status }) =>
        setMessages((m) => m.map((x) => (x.id === id ? { ...x, status } : x))),
      isPending: false,
    }),
  };

  return (
    <DataProviderContext.Provider value={provider}>
      {children}
    </DataProviderContext.Provider>
  );
}
