import type { ReactNode } from 'react';

import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface PostHeaderProps {
  kicker?: ReactNode;
  title: ReactNode;
  lede?: ReactNode;
  media: ReactNode;
  className?: string;
}

export function PostHeader( { kicker, title, lede, media, className = '' }: PostHeaderProps ) {
  return (
    <section
      data-header="solid"
      className={ cn( 'bg-background px-[var(--grid-margin)] pb-[120px] pt-[calc(var(--site-header-height)_+_0.25rem)] text-foreground', className ) }
    >
      <Reveal className="flex flex-col lg:grid lg:grid-cols-12 lg:items-start lg:gap-[var(--grid-gutter)]">
        <div
          className={ cn(
            'relative aspect-[3/4] overflow-hidden bg-muted lg:sticky lg:top-[var(--site-header-height)] lg:col-span-6',
            '[&>img]:absolute [&>img]:inset-0 [&>img]:h-full [&>img]:w-full [&>img]:object-cover'
          ) }
        >
          { media }
        </div>
        { kicker && <p className="m-0 mt-10 lg:col-span-2 lg:col-start-7 lg:row-start-1 lg:mt-20">{ kicker }</p> }
        <div className="mt-10 lg:col-span-3 lg:col-start-9 lg:row-start-1 lg:mt-[180px]">
          <h1 className="m-0 text-h2">{ title }</h1>
          { lede && <p className="m-0 mt-5">{ lede }</p> }
        </div>
      </Reveal>
    </section>
  );
}
