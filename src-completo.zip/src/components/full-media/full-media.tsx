import type { ReactNode } from 'react';
import { useRef } from 'react';

import { TextLink } from '@/components/base/text-link';
import { useParallax } from '@/components/parallax/use-parallax';
import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface FullMediaProps {
  media: ReactNode;
  label?: ReactNode;
  text?: ReactNode;
  href?: string;
  actionLabel?: string;
  parallax?: number;
  scale?: 'caption' | 'display';
  position?: 'top-left' | 'bottom-left' | 'center';
  title?: ReactNode;
  className?: string;
}

const shades = {
  'top-left': 'bg-gradient-to-b from-black/50 to-transparent to-60%',
  'bottom-left': 'bg-gradient-to-b from-transparent from-40% to-black/60',
  center: 'bg-black/35'
};

export function FullMedia( {
  media, label, text, href, actionLabel, parallax = 0.15, scale = 'caption', position = 'top-left', title, className = ''
}: FullMediaProps ) {
  const layerRef = useRef<HTMLDivElement>( null );

  useParallax( layerRef, parallax );

  return (
    <section data-header="over-media" className={ cn( 'relative text-white', className ) }>
      <Reveal>
      { href && (
        <TextLink href={ href } aria-label={ actionLabel } className="absolute inset-0 z-[1] border-0" tabIndex={ -1 }>
          <span className="sr-only">{ actionLabel }</span>
        </TextLink>
      ) }
      <div className="relative aspect-[9/16] w-full lg:aspect-video">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 scale-[1.08]">
            <div
              ref={ layerRef }
              className="absolute inset-x-0 -bottom-[20%] -top-[20%] will-change-transform [&>img]:h-full [&>img]:w-full [&>img]:object-cover"
            >
              { media }
            </div>
          </div>
        </div>
        <div className={ cn( 'pointer-events-none absolute inset-0', scale === 'display' ? shades[position] : 'bg-black/20' ) } aria-hidden="true" />
        { scale === 'display' && (
          <div
            className={ cn(
              'z-[2] px-[var(--grid-margin)]',
              position === 'top-left' && 'sticky top-16 py-8',
              position === 'bottom-left' && 'absolute inset-0 flex flex-col justify-end py-10',
              position === 'center' && 'absolute inset-0 flex flex-col items-center justify-center text-center'
            ) }
          >
            <div className={ cn( 'flex flex-col gap-5', position === 'bottom-left' && 'sticky bottom-10', position === 'center' && 'items-center' ) }>
              { label && <p className="m-0 text-white/80">{ label }</p> }
              { title && (
                <h2 className="m-0 text-h1 [font-family:var(--font-heading)] [--heading-font-weight:max(var(--font-heading-weight),500)]">
                  { title }
                </h2>
              ) }
              { ( text || ( href && actionLabel ) ) && (
                <div className="flex flex-col gap-4 lg:w-[calc(var(--col)*4_-_var(--grid-gutter))]">
                  { text && <div>{ text }</div> }
                  { href && actionLabel && <div><TextLink href={ href }>{ actionLabel }</TextLink></div> }
                </div>
              ) }
            </div>
          </div>
        ) }
        { scale === 'caption' && ( label || text ) && (
          <div className="sticky top-16 z-[2] flex flex-col gap-5 px-[var(--grid-margin)] py-8 lg:flex-row lg:gap-[var(--grid-gutter)]">
            <div className="lg:w-[calc(var(--col)*8_-_var(--grid-gutter))]">{ label }</div>
            <div className="flex flex-col gap-4">
              { text && <div className="max-w-[24.875rem] lg:w-[calc(var(--col)*4_-_var(--grid-gutter))]">{ text }</div> }
              { href && actionLabel && <div><TextLink href={ href }>{ actionLabel }</TextLink></div> }
            </div>
          </div>
        ) }
      </div>
      </Reveal>
    </section>
  );
}
