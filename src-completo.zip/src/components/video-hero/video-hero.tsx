import '@/styles/site-grid.css';
import './video-hero.css';

import type { ReactNode } from 'react';
import { useCallback, useEffect, useRef, useState } from 'react';

import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';
import { useParallax } from '../parallax/use-parallax';

const noCleanup = (): void => undefined;

function prefersLessMotion(): boolean {
  return typeof window !== 'undefined' && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
}

export interface HeroVideoProps {
  src: string;
  poster: string;
  shade?: boolean;
}

export function HeroVideo( { src, poster, shade = false }: HeroVideoProps ) {
  const [ still ] = useState( prefersLessMotion );
  const [ playing, setPlaying ] = useState( false );
  const onPlaying = useCallback( () => {
    setPlaying( true );
  }, [] );

  return (
    <div className="group absolute inset-0" data-playing={ playing ? 'true' : 'false' }>
      <img className="absolute inset-0 h-full w-full object-cover" src={ poster } alt="" />
      { !still && (
        <video
          className={ cn(
            'absolute inset-0 h-full w-full object-cover opacity-0 transition-opacity duration-500',
            'ease-linear group-data-[playing=true]:opacity-100'
          ) }
          src={ src }
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          aria-hidden="true"
          onPlaying={ onPlaying }
        />
      ) }
      { shade && <div className="pointer-events-none absolute inset-0 bg-black/20" aria-hidden="true" /> }
    </div>
  );
}

export interface VideoHeroProps {
  src: string;
  poster: string;
  title: string;
  wordmark: ReactNode;
  caption?: ReactNode;
  parallax?: number;
  className?: string;
}

export function VideoHero( { src, poster, title, wordmark, caption, parallax = 0.15, className = '' }: VideoHeroProps ) {
  const layerRef = useRef<HTMLDivElement>( null );
  const wordmarkRef = useRef<HTMLDivElement>( null );
  const [ shown, setShown ] = useState( false );

  useParallax( layerRef, parallax );

  useEffect( () => {
    const el = wordmarkRef.current;
    if ( !el ) {
      return noCleanup;
    }
    const observer = new IntersectionObserver( entries => {
      setShown( entries[entries.length - 1].isIntersecting );
    } );
    observer.observe( el );
    return () => {
      observer.disconnect();
    };
  }, [] );

  return (
    <section
      className={ cn( 'relative h-svh min-h-screen overflow-hidden bg-black text-white', className ) }
      data-header="over-media"
      data-caption={ caption ? 'true' : undefined }
    >
      <div className="video-hero-settle absolute inset-0">
        <div className="absolute inset-x-0 -bottom-[20%] -top-[20%] will-change-transform" ref={ layerRef }>
          <HeroVideo src={ src } poster={ poster } />
        </div>
      </div>
      <div className="pointer-events-none absolute inset-0 bg-black/20" aria-hidden="true" />
      <h1 className="sr-only">{ title }</h1>
      <div className="pointer-events-none absolute inset-0 grid place-items-center">
        <div
          ref={ wordmarkRef }
          data-shown={ shown ? 'true' : 'false' }
          aria-hidden="true"
          className={ cn(
            'w-[calc(var(--col)*5_-_var(--grid-gutter))] lg:w-[calc(var(--col)*6_-_var(--grid-gutter))]',
            'translate-y-10 opacity-0 transition-[opacity,transform,translate] duration-1000 [transition-timing-function:var(--site-ease)]',
            'data-[shown=true]:translate-y-0 data-[shown=true]:opacity-100',
            'motion-reduce:translate-y-0 motion-reduce:opacity-100 motion-reduce:transition-none',
            '[&_svg]:block [&_svg]:h-auto [&_svg]:w-full'
          ) }
        >
          { wordmark }
        </div>
      </div>
      { caption && (
        <Reveal
          order={ 8 }
          variant="rise"
          className={ cn(
            'pointer-events-none absolute inset-x-0 bottom-0 px-[var(--grid-margin)] pb-5 pt-[10svh]',
            '[&_a]:pointer-events-auto lg:[&>*]:max-w-[calc(var(--col)*5_-_var(--grid-gutter))]'
          ) }
        >
          { caption }
        </Reveal>
      ) }
    </section>
  );
}
