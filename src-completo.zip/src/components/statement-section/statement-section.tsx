import type { ReactNode } from 'react';

import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface StatementSectionProps {
  eyebrow?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  ruled?: boolean;
  className?: string;
}

export function StatementSection( { eyebrow, children, action, ruled = false, className = '' }: StatementSectionProps ) {
  return (
    <section data-header="solid" className={ cn( 'bg-background text-foreground', className ) }>
      <Reveal>
      <div className="flex flex-col gap-[3.75rem] px-[var(--grid-margin)] py-10 lg:py-[3.75rem]">
        { ruled && <hr className="m-0 -mb-5 h-px border-0 bg-current opacity-20" /> }
        <div className={ cn( 'flex flex-col', ruled ? 'gap-11' : 'gap-10' ) }>
          { eyebrow && <p className={ cn( 'm-0', ruled && 'text-meta' ) }>{ eyebrow }</p> }
          <h2
            className={ cn(
              'm-0 text-h2',
              '[font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)] lg:max-w-[calc(var(--col)*11_-_var(--grid-gutter))]'
            ) }
          >
            { children }
          </h2>
        </div>
        { action && <div className="">{ action }</div> }
      </div>
      </Reveal>
    </section>
  );
}
