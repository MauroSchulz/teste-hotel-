import type { ReactNode } from 'react';
import { useCallback, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';

import { TextLink } from '@/components/base/text-link';
import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface CollectionFilter {
  id: string;
  label: string;
  text?: ReactNode;
}

export interface CollectionItem {
  id: string;
  filter: string;
  href: string;
  kicker?: ReactNode;
  name: ReactNode;
  detail?: ReactNode;
  image: ReactNode;
}

export interface CollectionIndexProps {
  title: string;
  filters: CollectionFilter[];
  items: CollectionItem[];
  empty?: ReactNode;
  layout?: 'filters' | 'shop';
  groups?: Array<{ id: string; title: ReactNode; text?: ReactNode }>;
  className?: string;
}

function FilterButton( { filter, count, chosen, onChoose }: { filter: CollectionFilter; count: number; chosen: boolean; onChoose: ( id: string ) => void } ) {
  const onClick = useCallback( () => {
    onChoose( filter.id );
  }, [ filter.id, onChoose ] );

  return (
    <li>
      <button
        type="button"
        aria-pressed={ chosen }
        onClick={ onClick }
        className={ cn( 'type-heading m-0 cursor-pointer border-0 bg-transparent p-0 text-left text-h2 text-inherit transition-opacity', chosen ? 'opacity-100' : 'opacity-50 hover:opacity-100' ) }
      >
        { filter.label }
        <span className="ml-2.5 opacity-50">{ count }</span>
      </button>
    </li>
  );
}

function ShopIndex( { title, filters, groups, items, className }: { title: string; filters: CollectionFilter[]; groups: Array<{ id: string; title: ReactNode; text?: ReactNode }>; items: CollectionItem[]; className: string } ) {
  const [ params ] = useSearchParams();
  const chosen = params.get( 'group' );
  const shown = chosen ? groups.filter( group => group.id === chosen ) : groups;
  const note = filters[0]?.text;

  return (
    <section data-header="solid" className={ cn( 'bg-background px-[var(--grid-margin)] pb-[120px] pt-[calc(var(--site-header-height)_+_3.75rem)] text-foreground', className ) }>
      <h1 className="sr-only">{ title }</h1>
      <nav aria-label="Collections" className="-mx-[var(--grid-margin)] overflow-x-auto px-[var(--grid-margin)] [scrollbar-width:none]">
        <ul className="m-0 flex w-max list-none gap-8 p-0">
          <li><Link to="?" aria-current={ chosen ? undefined : 'page' } className={ cn( 'text-meta text-small no-underline', !chosen && 'border-b border-current pb-1' ) }>All</Link></li>
          { groups.map( group => (
            <li key={ group.id }>
              <Link to={ `?group=${ group.id }` } aria-current={ chosen === group.id ? 'page' : undefined } className={ cn( 'text-meta text-small no-underline', chosen === group.id && 'border-b border-current pb-1' ) }>
                { group.title }
              </Link>
            </li>
          ) ) }
        </ul>
      </nav>
      { note && <p className="m-0 mt-10 max-w-[40rem]">{ note }</p> }
      <div className="mt-16 flex flex-col gap-[120px]">
        { shown.map( group => (
          <section key={ group.id } aria-labelledby={ `group-${ group.id }` }>
            <h2 id={ `group-${ group.id }` } className="m-0 text-h2">{ group.title }</h2>
            { group.text && <p className="m-0 mt-3 max-w-[40rem]">{ group.text }</p> }
            <ul className="m-0 mt-8 grid list-none grid-cols-2 gap-x-[var(--grid-gutter)] gap-y-10 p-0 lg:grid-cols-4">
              { items.filter( item => item.filter === group.id ).map( item => (
                <Reveal as="li" key={ item.id }>
                  <TextLink href={ item.href } className="flex flex-col items-start border-0 text-left [&_img]:h-full [&_img]:w-full [&_img]:object-cover">
                    <span className="frame block aspect-[3/4] w-full overflow-hidden bg-muted">{ item.image }</span>
                    <span className="mt-3 block text-large">{ item.name }</span>
                    { item.detail && <span className="text-meta mt-0.5 block text-small">{ item.detail }</span> }
                  </TextLink>
                </Reveal>
              ) ) }
            </ul>
          </section>
        ) ) }
      </div>
    </section>
  );
}

export function CollectionIndex( { layout = 'filters', groups = [], className = '', ...rest }: CollectionIndexProps ) {
  return layout === 'shop' ?
    <ShopIndex title={ rest.title } filters={ rest.filters } groups={ groups } items={ rest.items } className={ className } /> :
    <FilterIndex { ...rest } className={ className } />;
}

function FilterIndex( { title, filters, items, empty = 'Nothing here yet.', className = '' }: Omit<CollectionIndexProps, 'layout' | 'groups'> ) {
  const allId = filters[0]?.id;
  const [ chosen, setChosen ] = useState( allId );
  const onChoose = useCallback( ( id: string ) => {
    setChosen( id );
  }, [] );

  const countOf = useCallback( ( id: string ) => ( id === allId ? items.length : items.filter( item => item.filter === id ).length ), [ allId, items ] );
  const shown = useMemo( () => ( chosen === allId ? items : items.filter( item => item.filter === chosen ) ), [ allId, chosen, items ] );
  const text = filters.find( filter => filter.id === chosen )?.text;

  return (
    <section
      data-header="solid"
      className={ cn( 'bg-background px-[var(--grid-margin)] pb-[120px] pt-[calc(var(--site-header-height)_+_3.75rem)] text-foreground lg:pt-[calc(var(--site-header-height)_+_4rem)]', className ) }
    >
      <h1 className="sr-only">{ title }</h1>
      <div className="flex flex-col gap-10 lg:grid lg:grid-cols-12 lg:gap-[var(--grid-gutter)]">
        <ul className="m-0 flex list-none flex-col p-0 lg:col-span-8">
          { filters.map( filter => (
            <FilterButton key={ filter.id } filter={ filter } count={ countOf( filter.id ) } chosen={ filter.id === chosen } onChoose={ onChoose } />
          ) ) }
        </ul>
        { text && <p className="m-0 lg:col-span-4 lg:col-start-9">{ text }</p> }
      </div>
      { shown.length === 0 ? (
        <p className="m-0 mt-10 opacity-50 lg:mt-20">{ empty }</p>
      ) : (
        <ul className="m-0 mt-10 grid list-none grid-cols-1 gap-x-[var(--grid-gutter)] gap-y-[60px] p-0 lg:mt-20 lg:grid-cols-3">
          { shown.map( item => (
            <Reveal as="li" key={ item.id }>
              <TextLink href={ item.href } className="flex flex-col items-start justify-start border-0 text-left [&_img]:h-full [&_img]:w-full [&_img]:object-cover">
                <span className="block aspect-[3/4] w-full overflow-hidden bg-muted">{ item.image }</span>
                { item.kicker && <span className="mt-3 block text-small opacity-50">{ item.kicker }</span> }
                <span className={ cn( 'block text-large', item.kicker ? 'mt-1' : 'mt-3' ) }>{ item.name }</span>
                { item.detail && <span className="block">{ item.detail }</span> }
              </TextLink>
            </Reveal>
          ) ) }
        </ul>
      ) }
    </section>
  );
}
