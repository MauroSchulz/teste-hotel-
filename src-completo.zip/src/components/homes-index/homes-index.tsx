import type { ReactNode, TransitionEvent } from 'react';
import { useCallback, useEffect, useMemo, useState } from 'react';

import { PlayPauseButton } from '@/components/base/play-pause-button';
import { TextLink } from '@/components/base/text-link';
import { playStateOf, useSequence } from '@/components/sequence/use-sequence';
import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface HomesArea {
  id: string;
  label: string;
  text?: ReactNode;
}

export interface HomesSold {
  label: string;
  text?: ReactNode;
}

export interface HomesItem {
  id: string;
  area: string;
  href: string;
  name: ReactNode;
  status?: string;
  price: number;
  facts?: ReactNode;
  image: ReactNode;
}

export interface HomesIndexProps {
  title: string;
  areas: HomesArea[];
  sold?: HomesSold;
  homes: HomesItem[];
  ground?: string;
  ink?: string;
  className?: string;
}

const SOLD = 'sold';

const full = ( price: number ): string => `£${ price.toLocaleString( 'en-GB' ) }`;
const short = ( price: number ): string => `£${ Math.round( price / 1000 ) }k`;

function SoldHero( { homes }: { homes: HomesItem[] } ) {
  const [ still, setStill ] = useState( true );
  const { state, leaving, paused, start, stepShown, clearLeaving, toggle } = useSequence( { count: homes.length, hold: 4, fadeMs: 800, loop: true } );
  const swaps = homes.length > 1 && !still;

  useEffect( () => {
    const quiet = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    setStill( quiet );
    if ( !quiet && homes.length > 1 ) {
      start();
    }
  }, [ homes.length, start ] );

  const onLayerTransitionEnd = useCallback( ( event: TransitionEvent<HTMLDivElement> ) => {
    if ( event.target !== event.currentTarget || event.propertyName !== 'opacity' ) {
      return;
    }
    if ( event.currentTarget.dataset.state === 'leaving' ) {
      clearLeaving();
      return;
    }
    stepShown();
  }, [ clearLeaving, stepShown ] );

  return (
    <section data-header="over-media" aria-label="Recently sold" className="relative h-[85svh] min-h-[32rem] overflow-hidden bg-foreground text-white" data-state={ playStateOf( state, paused ) }>
      { homes.map( ( home, i ) => {
        const current = i === state.index;
        return (
          <div
            key={ home.id }
            data-state={ current ? 'current' : i === leaving ? 'leaving' : 'hidden' }
            aria-hidden={ current ? undefined : 'true' }
            onTransitionEnd={ onLayerTransitionEnd }
            className={ cn( 'absolute inset-0 transition-opacity duration-[800ms] [transition-timing-function:var(--site-ease)]', current ? 'opacity-100' : 'opacity-0' ) }
          >
            <div className="absolute inset-0 [&>img]:h-full [&>img]:w-full [&>img]:object-cover">{ home.image }</div>
            <div className="absolute inset-0 bg-gradient-to-b from-black/30 from-0% via-transparent via-30% to-black/70" />
            <TextLink href={ home.href } tabIndex={ current ? undefined : -1 } className="absolute bottom-[clamp(1.5rem,4vw,3rem)] left-[var(--grid-margin)] flex flex-col items-start border-0 p-0 text-left">
              <span className="block text-large">{ home.name }<span className="opacity-70"> / { home.status }</span></span>
              <span className="block text-h2 type-heading">{ full( home.price ) }</span>
              { home.facts && <span className="mt-1 block text-small opacity-70">{ home.facts }</span> }
            </TextLink>
          </div>
        );
      } ) }
      { swaps && <PlayPauseButton paused={ paused } onToggle={ toggle } label="sold homes" className="absolute bottom-[clamp(1.5rem,4vw,3rem)] right-[var(--grid-margin)]" /> }
    </section>
  );
}

function AreaButton( { id, label, count, chosen, onChoose }: { id: string; label: string; count: number; chosen: boolean; onChoose: ( id: string ) => void } ) {
  const onClick = useCallback( () => {
    onChoose( id );
  }, [ id, onChoose ] );

  return (
    <li>
      <button
        type="button"
        aria-pressed={ chosen }
        onClick={ onClick }
        className={ cn( 'type-heading m-0 max-w-full cursor-pointer border-0 bg-transparent p-0 text-left text-h4 text-inherit transition-opacity', chosen ? 'opacity-100' : 'opacity-50 hover:opacity-100' ) }
      >
        { label }
        <span className="ml-2.5 opacity-50">{ count }</span>
      </button>
    </li>
  );
}

export function HomesIndex( { title, areas, sold, homes, ground, ink, className = '' }: HomesIndexProps ) {
  const allId = areas[0]?.id;
  const [ chosen, setChosen ] = useState( allId );
  const onChoose = useCallback( ( id: string ) => {
    setChosen( id );
  }, [] );

  const forSale = useMemo( () => homes.filter( home => home.status !== 'Sold' ), [ homes ] );
  const soldHomes = useMemo( () => homes.filter( home => home.status === 'Sold' ), [ homes ] );
  const inArea = useCallback( ( id: string ) => ( id === allId ? forSale : forSale.filter( home => home.area === id ) ), [ allId, forSale ] );
  const shown = chosen === SOLD ? soldHomes : inArea( chosen );
  const summary = ( id: string ): string | undefined => {
    const list = id === SOLD ? soldHomes : inArea( id );
    if ( list.length === 0 ) {
      return undefined;
    }
    const lowest = Math.min( ...list.map( home => home.price ) );
    return id === SOLD ? `${ list.length } sold, from ${ short( lowest ) }` : `${ list.length } ${ list.length === 1 ? 'home' : 'homes' } from ${ short( lowest ) }`;
  };
  const panels = [ ...areas.map( area => ( { id: area.id, text: area.text } ) ), ...( sold ? [ { id: SOLD, text: sold.text } ] : [] ) ];

  return (
    <div className={ className }>
      <h1 className="sr-only">{ title }</h1>
      { soldHomes.length > 0 && <SoldHero homes={ soldHomes } /> }
      <section
        data-header="solid"
        style={ { backgroundColor: ground, color: ink } }
        className="bg-background px-[var(--grid-margin)] pb-[120px] pt-[3.75rem] text-foreground lg:pt-20"
      >
        <ul className="m-0 flex list-none flex-wrap items-baseline gap-x-8 gap-y-2 p-0 lg:gap-x-12">
          { areas.map( area => {
            const list = inArea( area.id );
            return (
              <AreaButton
                key={ area.id }
                id={ area.id }
                label={ area.label }
                count={ list.length }
                chosen={ area.id === chosen }
                onChoose={ onChoose }
              />
            );
          } ) }
          { sold && <AreaButton id={ SOLD } label={ sold.label } count={ soldHomes.length } chosen={ chosen === SOLD } onChoose={ onChoose } /> }
        </ul>
        { panels.map( panel => panel.id === chosen && (
          <p key={ panel.id } className="m-0 mt-10 lg:mt-12 lg:w-[calc(var(--col)*5_-_var(--grid-gutter))]">
            { summary( panel.id ) && <span className="block text-large">{ summary( panel.id ) }</span> }
            { panel.text && <span className="mt-2 block">{ panel.text }</span> }
          </p>
        ) ) }
        <ul className="mx-0 mb-0 mt-20 grid list-none grid-cols-1 gap-x-[var(--grid-gutter)] gap-y-[60px] p-0 lg:grid-cols-12">
          { shown.map( ( home, i ) => (
            <Reveal as="li" key={ home.id } className={ cn( 'lg:col-span-4', i === 0 && 'lg:col-span-6', i === 1 && 'lg:col-start-9' ) }>
              <TextLink href={ home.href } className="flex flex-col items-start justify-start border-0 text-left [&_img]:h-full [&_img]:w-full [&_img]:object-cover">
                <span className={ cn( 'block aspect-[3/4] w-full overflow-hidden bg-muted', i === 0 && 'lg:aspect-auto lg:h-[calc((var(--col)*4_-_var(--grid-gutter))*4/3)]' ) }>
                  { home.image }
                </span>
                <span className="mt-3 block text-large">
                  { home.name }
                  { home.status && <span className="opacity-50"> / { home.status }</span> }
                </span>
                <span className="mt-1 block text-large">{ full( home.price ) }</span>
                { home.facts && <span className="mt-1 block text-small opacity-50">{ home.facts }</span> }
              </TextLink>
            </Reveal>
          ) ) }
        </ul>
      </section>
    </div>
  );
}
