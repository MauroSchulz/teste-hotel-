import type { ReactNode } from 'react';

import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface TextMediaProps {
  label?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  media: ReactNode;
  className?: string;
}

export function TextMedia( { label, children, action, media, className = '' }: TextMediaProps ) {
  return (
    <section data-header="solid" className={ cn( 'bg-background py-10 text-foreground lg:py-[3.75rem]', className ) }>
      <Reveal>
      <div className="grid grid-cols-1 items-start gap-[var(--grid-gutter)] px-[var(--grid-margin)] lg:grid-cols-2">
        <div className="order-2 flex flex-col gap-10 pt-10 lg:order-1 lg:gap-[3.75rem] lg:pt-[3.75rem]">
          { label && <p className="m-0 lg:w-[calc(var(--col)*2_-_var(--grid-gutter))]">{ label }</p> }
          <div className="flex flex-col gap-[1.3em] lg:ml-[calc(var(--col)*2)] lg:w-[calc(var(--col)*3_-_var(--grid-gutter))]">
            { children }
            { action && <div>{ action }</div> }
          </div>
        </div>
        <div
          className={ cn(
            'relative order-1 aspect-[3/4] overflow-hidden lg:order-2',
            '[&>img]:absolute [&>img]:inset-0 [&>img]:h-full [&>img]:w-full [&>img]:object-cover'
          ) }
        >
          { media }
        </div>
      </div>
      </Reveal>
    </section>
  );
}
