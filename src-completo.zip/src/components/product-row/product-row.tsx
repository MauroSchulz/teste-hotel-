import type { ReactNode } from 'react';
import { useCallback, useRef, useState } from 'react';

import { IconArrowLeft, IconArrowRight } from '@tabler/icons-react';

import { TextLink } from '@/components/base/text-link';
import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface ProductRowItem {
  id: string;
  href: string;
  name: ReactNode;
  detail?: ReactNode;
  image: ReactNode;
  hoverImage?: ReactNode;
}

export interface ProductRowProps {
  title?: ReactNode;
  action?: ReactNode;
  items: ProductRowItem[];
  layout?: 'grid' | 'scroll';
  label?: ReactNode;
  className?: string;
}

const layerClass = 'absolute inset-0 transition-opacity duration-500 [transition-timing-function:var(--site-ease)] [&>img]:h-full [&>img]:w-full [&>img]:object-cover';

function ProductCard( { item, compact = false }: { item: ProductRowItem; compact?: boolean } ) {
  const [ hovered, setHovered ] = useState( false );
  const canHover = typeof window !== 'undefined' && window.matchMedia( '(hover: hover)' ).matches;
  const onEnter = useCallback( () => {
    if ( canHover ) {
      setHovered( true );
    }
  }, [ canHover ] );
  const onLeave = useCallback( () => {
    setHovered( false );
  }, [] );

  return (
    <li data-card className={ cn( 'flex flex-col gap-3', compact && 'w-[60vw] shrink-0 snap-center lg:w-[calc(var(--col)*3_-_var(--grid-gutter))]' ) } onMouseEnter={ onEnter } onMouseLeave={ onLeave }>
      <TextLink href={ item.href } className={ cn( 'relative block aspect-[3/4] overflow-hidden border-0 bg-muted', compact && 'frame' ) } aria-label={ typeof item.name === 'string' ? item.name : undefined }>
        <span className={ cn( layerClass, hovered && item.hoverImage ? 'opacity-0' : 'opacity-100' ) }>{ item.image }</span>
        { item.hoverImage && (
          <span className={ cn( layerClass, hovered ? 'opacity-100' : 'opacity-0' ) } aria-hidden="true">{ item.hoverImage }</span>
        ) }
      </TextLink>
      { compact ? (
        <div className="flex flex-col gap-1 text-center">
          <h3 className="m-0 text-large [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]">{ item.name }</h3>
          { item.detail && <p className="text-meta m-0 text-small">{ item.detail }</p> }
        </div>
      ) : (
        <div className="flex flex-col gap-0.5">
          <h3 className="m-0 text-h3 [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]">
            { item.name }
          </h3>
          { item.detail && <p className="m-0 text-muted-foreground">{ item.detail }</p> }
        </div>
      ) }
    </li>
  );
}

function ScrollRow( { title, label, action, items, className }: { title?: ReactNode; label?: ReactNode; action?: ReactNode; items: ProductRowItem[]; className: string } ) {
  const trackRef = useRef<HTMLUListElement | null>( null );

  const move = useCallback( ( direction: 1 | -1 ) => {
    const track = trackRef.current;
    if ( !track ) {
      return;
    }
    const card = track.querySelector<HTMLElement>( '[data-card]' );
    const gap = parseFloat( getComputedStyle( track ).columnGap ) || 0;
    const step = ( card?.offsetWidth ?? 0 ) + gap;
    const max = track.scrollWidth - track.clientWidth;
    const behavior = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ? 'auto' : 'smooth';
    if ( direction === 1 && track.scrollLeft >= max - 2 ) {
      track.scrollTo( { left: 0, behavior } );
    } else if ( direction === -1 && track.scrollLeft <= 2 ) {
      track.scrollTo( { left: max, behavior } );
    } else {
      track.scrollBy( { left: direction * step, behavior } );
    }
  }, [] );
  const onPrev = useCallback( () => {
    move( -1 );
  }, [ move ] );
  const onNext = useCallback( () => {
    move( 1 );
  }, [ move ] );

  return (
    <section data-header="solid" className={ cn( 'frame-rule bg-background py-20 text-foreground lg:py-[7.5rem]', className ) }>
      <Reveal>
        { ( label || title ) && (
          <div className="mb-10 px-[var(--grid-margin)] text-center">
            { label && <p className="text-meta m-0 mb-2.5 text-small">{ label }</p> }
            { title && <h2 className="m-0 text-h2 [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]">{ title }</h2> }
          </div>
        ) }
        <ul
          ref={ trackRef }
          className="m-0 flex list-none snap-x snap-mandatory gap-[var(--grid-gutter)] overflow-x-auto scroll-smooth p-0 px-[calc(50%_-_30vw)] [scrollbar-width:none] lg:px-[calc(50%_-_(var(--col)*3_-_var(--grid-gutter))/2)] motion-reduce:scroll-auto"
        >
          { items.map( item => <ProductCard key={ item.id } item={ item } compact /> ) }
        </ul>
        <div className="mt-8 grid grid-cols-[1fr_auto_1fr] items-center gap-5 px-[var(--grid-margin)]">
          <button type="button" onClick={ onPrev } aria-label="Previous" className="justify-self-start border-0 bg-transparent p-2 text-inherit">
            <IconArrowLeft size={ 28 } stroke={ 1 } aria-hidden="true" />
          </button>
          <div>{ action }</div>
          <button type="button" onClick={ onNext } aria-label="Next" className="justify-self-end border-0 bg-transparent p-2 text-inherit">
            <IconArrowRight size={ 28 } stroke={ 1 } aria-hidden="true" />
          </button>
        </div>
      </Reveal>
    </section>
  );
}

export function ProductRow( { title, action, items, layout = 'grid', label, className = '' }: ProductRowProps ) {
  if ( layout === 'scroll' ) {
    return <ScrollRow title={ title } label={ label } action={ action } items={ items } className={ className } />;
  }
  return (
    <section data-header="solid" className={ cn( 'bg-background text-foreground', className ) }>
      <Reveal>
      <div className="flex flex-col gap-8 px-[var(--grid-margin)] py-10 lg:py-[3.75rem]">
        { ( title || action ) && (
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between lg:gap-[var(--grid-gutter)]">
            { title && (
              <h2 className="m-0 text-h2 [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]">
                { title }
              </h2>
            ) }
            { action && <div>{ action }</div> }
          </div>
        ) }
        <ul className="m-0 grid list-none grid-cols-1 gap-10 p-0 lg:grid-cols-3 lg:gap-[var(--grid-gutter)]">
          { items.map( item => <ProductCard key={ item.id } item={ item } /> ) }
        </ul>
      </div>
      </Reveal>
    </section>
  );
}
