import '@/styles/site-grid.css';

import type { CSSProperties } from 'react';
import { useEffect, useRef, useState } from 'react';

import { cn } from '@/lib/utils';
import { TextLink } from '../base/text-link';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

const noCleanup = (): void => undefined;

export interface SiteHeaderLink {
  label: string;
  href: string;
}

export interface SiteHeaderProps {
  name: string;
  home?: string;
  start?: SiteHeaderLink[];
  end?: SiteHeaderLink[];
  overlay?: boolean;
  linkFont?: 'body' | 'heading';
  className?: string;
}

type Under = { kind: 'page' } | { kind: 'media' } | { kind: 'solid'; ground: string; ink: string };

function isTransparent( colour: string ): boolean {
  return colour === 'transparent' || /rgba\(.*,\s*0\)$/.test( colour );
}

export function SiteHeader( { name, home = '/', start = [], end = [], overlay = false, linkFont = 'body', className = '' }: SiteHeaderProps ) {
  const ref = useRef<HTMLElement>( null );
  const [ under, setUnder ] = useState<Under>( { kind: 'page' } );

  useEffect( () => {
    const header = ref.current;
    if ( !header ) {
      return noCleanup;
    }
    let observer: IntersectionObserver | null = null;
    const inBand = new Set<HTMLElement>();

    const pick = () => {
      const el = [ ...inBand ].pop();
      if ( !el ) {
        setUnder( { kind: 'page' } );
        return;
      }
      if ( el.dataset.header === 'over-media' ) {
        setUnder( { kind: 'media' } );
        return;
      }
      const style = getComputedStyle( el );
      setUnder( isTransparent( style.backgroundColor ) ?
        { kind: 'page' } :
        { kind: 'solid', ground: style.backgroundColor, ink: style.color } );
    };

    const watch = () => {
      observer?.disconnect();
      inBand.clear();
      const height = header.offsetHeight;
      observer = new IntersectionObserver( entries => {
        entries.forEach( entry => {
          if ( entry.isIntersecting ) {
            inBand.add( entry.target as HTMLElement );
          } else {
            inBand.delete( entry.target as HTMLElement );
          }
        } );
        pick();
      }, { rootMargin: `-${ height }px 0px -${ Math.max( 0, window.innerHeight - height - 1 ) }px 0px` } );
      document.querySelectorAll( '[data-header]' ).forEach( el => observer?.observe( el ) );
    };

    watch();
    window.addEventListener( 'resize', watch );
    return () => {
      window.removeEventListener( 'resize', watch );
      observer?.disconnect();
    };
  }, [] );

  const solid: CSSProperties | undefined = under.kind === 'solid' ? { backgroundColor: under.ground, color: under.ink } : undefined;

  return (
    <header
      ref={ ref }
      style={ solid }
      data-over-media={ under.kind === 'media' ? 'true' : undefined }
      className={ cn(
        overlay ? 'fixed inset-x-0 top-0' : 'sticky top-0',
        'z-[100] flex h-[var(--site-header-height)] items-center justify-between',
        'px-[var(--grid-margin)] transition-colors duration-100',
        linkFont === 'heading' ? '[font-family:var(--font-heading)]' : '[font-family:var(--font-body)]',
        under.kind === 'page' && 'bg-background text-foreground',
        under.kind === 'media' && 'bg-gradient-to-b from-black/35 to-transparent text-white',
        className
      ) }
    >
      <nav className="hidden gap-5 lg:flex" aria-label="Primary">
        { start.map( link => <TextLink key={ link.href } href={ link.href } underline="hover">{ link.label }</TextLink> ) }
      </nav>
      <TextLink
        href={ home }
        underline="hover"
        className={ cn(
          'type-brand whitespace-nowrap text-small [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]',
          'lg:absolute lg:left-1/2 lg:-translate-x-1/2'
        ) }
      >
        { name }
      </TextLink>
      <div className="flex items-center gap-5">
        <nav className="flex gap-5" aria-label="Secondary">
          { end.map( link => <TextLink key={ link.href } href={ link.href } underline="hover">{ link.label }</TextLink> ) }
        </nav>
        { start.length > 0 && (
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" className="h-auto p-0 text-inherit hover:bg-transparent hover:text-inherit lg:hidden">Menu</Button>
            </DialogTrigger>
            <DialogContent className="bg-background text-foreground">
              <DialogTitle className="type-brand text-small [font-family:var(--font-heading)] [font-weight:var(--font-heading-weight)]">{ name }</DialogTitle>
              <nav className="grid gap-4 pt-2 text-h2 [font-family:var(--font-heading)]" aria-label="Menu">
                { [ ...start, ...end ].map( link => (
                  <TextLink key={ link.href } href={ link.href } underline="hover" className="justify-self-start">{ link.label }</TextLink>
                ) ) }
              </nav>
            </DialogContent>
          </Dialog>
        ) }
      </div>
    </header>
  );
}
