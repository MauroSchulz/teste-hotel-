import type { ReactNode } from 'react';
import { useCallback, useState } from 'react';

import { IconCheck } from '@tabler/icons-react';

import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { cn } from '@/lib/utils';

export interface ProductSize {
  id: string;
  label: string;
  price: string;
}

export interface ProductAddOn {
  id: string;
  name: string;
  image: ReactNode;
  options: Array<{ id: string; label: string }>;
}

export function SizeChoice( { sizes, value, onChange }: { sizes: ProductSize[]; value: string; onChange: ( id: string ) => void } ) {
  return (
    <fieldset className="m-0 mt-8 border-0 p-0">
      <legend className="text-meta mb-3 text-small">Size</legend>
      <RadioGroup value={ value } onValueChange={ onChange } className="flex flex-wrap gap-2">
        { sizes.map( size => (
          <Label
            key={ size.id }
            htmlFor={ `size-${ size.id }` }
            className={ cn( 'frame flex cursor-pointer items-center gap-2 px-4 py-2.5 text-[length:inherit] font-normal', value === size.id && 'bg-foreground text-background' ) }
          >
            <RadioGroupItem id={ `size-${ size.id }` } value={ size.id } className="sr-only" />
            { size.label } · { size.price }
          </Label>
        ) ) }
      </RadioGroup>
    </fieldset>
  );
}

function AddOnTile( { addOn, chosen, onOpen }: { addOn: ProductAddOn; chosen: boolean; onOpen: ( id: string ) => void } ) {
  const onClick = useCallback( () => {
    onOpen( addOn.id );
  }, [ addOn.id, onOpen ] );

  return (
    <button
      type="button"
      onClick={ onClick }
      aria-label={ chosen ? `${ addOn.name }, added` : `Add ${ addOn.name }` }
      className="frame relative block aspect-square cursor-pointer overflow-hidden border-0 bg-muted p-0 [&_img]:h-full [&_img]:w-full [&_img]:object-cover"
    >
      { addOn.image }
      { chosen && (
        <span className="absolute right-1.5 top-1.5 grid size-5 place-items-center rounded-full bg-foreground text-background" aria-hidden="true">
          <IconCheck size={ 12 } stroke={ 2.5 } />
        </span>
      ) }
    </button>
  );
}

export function AddOnChoice( { addOns, chosen, onChange }: { addOns: ProductAddOn[]; chosen: Record<string, string>; onChange: ( next: Record<string, string> ) => void } ) {
  const [ open, setOpen ] = useState<string | null>( null );
  const [ option, setOption ] = useState( '' );
  const current = addOns.find( addOn => addOn.id === open );

  const onOpen = useCallback( ( id: string ) => {
    const addOn = addOns.find( one => one.id === id );
    setOption( chosen[id] ?? addOn?.options[0]?.id ?? '' );
    setOpen( id );
  }, [ addOns, chosen ] );
  const onOpenChange = useCallback( ( next: boolean ) => {
    if ( !next ) {
      setOpen( null );
    }
  }, [] );
  const onAdd = useCallback( () => {
    if ( open ) {
      onChange( { ...chosen, [ open ]: option } );
    }
    setOpen( null );
  }, [ chosen, onChange, open, option ] );
  const onRemove = useCallback( () => {
    if ( open ) {
      const next = { ...chosen };
      delete next[open];
      onChange( next );
    }
    setOpen( null );
  }, [ chosen, onChange, open ] );

  return (
    <div className="mt-8">
      <p className="text-meta m-0 mb-3 text-small">Make it extra special</p>
      <div className="grid grid-cols-4 gap-3">
        { addOns.map( addOn => <AddOnTile key={ addOn.id } addOn={ addOn } chosen={ chosen[addOn.id] !== undefined } onOpen={ onOpen } /> ) }
      </div>
      <Dialog open={ current !== undefined } onOpenChange={ onOpenChange }>
        <DialogContent className="bg-background text-foreground sm:max-w-xl">
          { current && (
            <div className="flex flex-col gap-6 sm:flex-row">
              <div className="frame aspect-[3/4] w-full shrink-0 overflow-hidden bg-muted sm:w-40 [&_img]:h-full [&_img]:w-full [&_img]:object-cover">{ current.image }</div>
              <div className="flex flex-1 flex-col gap-5">
                <DialogTitle className="m-0 text-h4 font-normal">{ current.name }</DialogTitle>
                <RadioGroup value={ option } onValueChange={ setOption } className="flex flex-col gap-2">
                  { current.options.map( one => (
                    <Label key={ one.id } htmlFor={ `addon-${ one.id }` } className="flex cursor-pointer items-center gap-3 text-[length:inherit] font-normal">
                      <RadioGroupItem id={ `addon-${ one.id }` } value={ one.id } />
                      { one.label }
                    </Label>
                  ) ) }
                </RadioGroup>
                <div className="mt-auto flex gap-3">
                  <Button type="button" onClick={ onAdd }>{ chosen[current.id] ? 'Update' : 'Add' }</Button>
                  { chosen[current.id] && <Button type="button" variant="outline" onClick={ onRemove }>Remove</Button> }
                </div>
              </div>
            </div>
          ) }
        </DialogContent>
      </Dialog>
    </div>
  );
}
