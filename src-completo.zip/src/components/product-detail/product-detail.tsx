import type { ReactNode } from 'react';
import { useCallback, useState } from 'react';

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import type { ProductAddOn, ProductSize } from './product-options';
import { AddOnChoice, SizeChoice } from './product-options';
import { cn } from '@/lib/utils';

export interface ProductDetailGroup {
  id: string;
  title: ReactNode;
  rows: Array<[ ReactNode, ReactNode ]>;
}

export interface ProductDetailProps {
  photos: ReactNode[];
  title: ReactNode;
  price?: ReactNode;
  description?: ReactNode;
  features?: ReactNode[];
  note?: ReactNode;
  actions?: ReactNode[] | ( ( choice: ProductChoice ) => ReactNode[] );
  details?: ProductDetailGroup[];
  detailsOpen?: boolean;
  gallery?: 'thumbnails' | 'dots';
  sizes?: ProductSize[];
  addOns?: ProductAddOn[];
  className?: string;
}

export interface ProductChoice {
  size?: ProductSize;
  addOns: Array<{ addOn: ProductAddOn; option: string }>;
}

const lineTop = '[border-top:1px_solid_color-mix(in_srgb,currentColor_20%,transparent)]';

function Dot( { index, chosen, onChoose }: { index: number; chosen: boolean; onChoose: ( index: number ) => void } ) {
  const onClick = useCallback( () => {
    onChoose( index );
  }, [ index, onChoose ] );

  return (
    <button
      type="button"
      aria-pressed={ chosen }
      aria-label={ `Show photo ${ index + 1 }` }
      onClick={ onClick }
      className={ cn( 'block size-2 cursor-pointer rounded-full border border-current p-0', chosen ? 'bg-current' : 'bg-transparent' ) }
    />
  );
}

function Thumbnail( { index, photo, chosen, onChoose }: { index: number; photo: ReactNode; chosen: boolean; onChoose: ( index: number ) => void } ) {
  const onClick = useCallback( () => {
    onChoose( index );
  }, [ index, onChoose ] );

  return (
    <button
      type="button"
      aria-pressed={ chosen }
      aria-label={ `Show photo ${ index + 1 }` }
      onClick={ onClick }
      className={ cn( 'block h-24 w-20 cursor-pointer overflow-hidden border-0 bg-muted p-0 [&_img]:h-full [&_img]:w-full [&_img]:object-cover', chosen && 'outline outline-1 outline-current' ) }
    >
      { photo }
    </button>
  );
}

export function ProductDetail( { photos, title, price, description, features = [], note, actions = [], details = [], detailsOpen = false, gallery = 'thumbnails', sizes, addOns, className = '' }: ProductDetailProps ) {
  const [ chosen, setChosen ] = useState( 0 );
  const [ sizeId, setSizeId ] = useState( sizes?.[0]?.id ?? '' );
  const [ picked, setPicked ] = useState<Record<string, string>>( {} );
  const onChoose = useCallback( ( index: number ) => {
    setChosen( index );
  }, [] );
  const dots = gallery === 'dots';
  const size = sizes?.find( one => one.id === sizeId );
  const choice: ProductChoice = { size, addOns: ( addOns ?? [] ).filter( one => picked[one.id] !== undefined ).map( one => ( { addOn: one, option: picked[one.id] } ) ) };
  const shownActions = typeof actions === 'function' ? actions( choice ) : actions;
  const shownPrice = size ? size.price : price;
  const dotRow = photos.length > 1 && (
    <div className="flex gap-2.5 lg:flex-col" role="group" aria-label="Photos">
      { photos.map( ( _, i ) => <Dot key={ i } index={ i } chosen={ i === chosen } onChoose={ onChoose } /> ) }
    </div>
  );

  return (
    <section data-header="solid" className={ cn( 'bg-background pb-[120px] pt-[var(--site-header-height)] text-foreground', className ) }>
      <div className="flex flex-col gap-10 lg:grid lg:grid-cols-12 lg:items-start lg:gap-[var(--grid-gutter)] lg:px-[var(--grid-margin)]">
        <div className={ cn( 'hidden lg:sticky lg:top-[var(--site-header-height)] lg:col-span-6 lg:block lg:h-[calc(100svh_-_var(--site-header-height)_-_1.875rem)] lg:overflow-hidden lg:bg-muted [&_img]:h-full [&_img]:w-full [&_img]:object-cover', dots && 'frame lg:relative lg:overflow-visible' ) }>
          { dots && <div className="absolute -left-5 top-0 hidden lg:block">{ dotRow }</div> }
          { photos[chosen] }
        </div>
        { dots && (
          <div className="flex flex-col items-center gap-4 px-[var(--grid-margin)] lg:hidden">
            <div className="frame aspect-[3/4] w-full overflow-hidden bg-muted [&_img]:h-full [&_img]:w-full [&_img]:object-cover">{ photos[chosen] }</div>
            { dotRow }
          </div>
        ) }
        <ul
          aria-label="Photos"
          className={ cn( 'm-0 flex list-none snap-x snap-mandatory gap-[var(--grid-gutter)] overflow-x-auto p-0 [scrollbar-width:none] lg:hidden', dots && 'hidden' ) }
        >
          { photos.map( ( photo, i ) => (
            <li key={ i } className="aspect-[5/7] w-[90%] shrink-0 snap-start overflow-hidden bg-muted first:ml-[var(--grid-margin)] last:mr-[var(--grid-margin)] [&_img]:h-full [&_img]:w-full [&_img]:object-cover">
              { photo }
            </li>
          ) ) }
        </ul>
        <div className="flex flex-col px-[var(--grid-margin)] lg:col-span-4 lg:col-start-9 lg:px-0 lg:pt-[72px]">
          { photos.length > 1 && !dots && (
            <div className="mb-5 hidden min-h-[216px] flex-wrap content-start gap-2 lg:flex">
              { photos.map( ( photo, i ) => (
                <Thumbnail key={ i } index={ i } photo={ photo } chosen={ i === chosen } onChoose={ onChoose } />
              ) ) }
            </div>
          ) }
          <h1 className="m-0 text-h4">{ title }</h1>
          { shownPrice && <p className="m-0 mt-2 text-large">{ shownPrice }</p> }
          { description && <p className="m-0 mt-5">{ description }</p> }
          { features.length > 0 && (
            <ul className="m-0 mt-[30px] list-none p-0">
              { features.map( ( feature, i ) => (
                <li key={ i } className={ cn( 'text-meta flex h-9 items-center text-small', lineTop ) }>{ feature }</li>
              ) ) }
            </ul>
          ) }
          { note && <p className="m-0 mt-5">{ note }</p> }
          { sizes && sizes.length > 0 && <SizeChoice sizes={ sizes } value={ sizeId } onChange={ setSizeId } /> }
          { addOns && addOns.length > 0 && <AddOnChoice addOns={ addOns } chosen={ picked } onChange={ setPicked } /> }
          { shownActions.length > 0 && (
            <div className="mt-10 flex flex-col gap-2.5 [&>*]:h-[41px] [&>*]:w-full">{ shownActions }</div>
          ) }
          { details.length > 0 && (
            <Accordion type="multiple" defaultValue={ detailsOpen ? details.map( group => group.id ) : [] } className="mt-[60px]">
              { details.map( group => (
                <AccordionItem key={ group.id } value={ group.id } className="[&_h3]:!m-0 [&_h3]:!text-[length:inherit] [&_h3]:![font-family:inherit] [&_h3]:![font-weight:inherit] [&_h3]:![letter-spacing:inherit] [&_h3]:![line-height:inherit]">
                  <AccordionTrigger className="text-left font-normal">{ group.title }</AccordionTrigger>
                  <AccordionContent>
                    <dl className="m-0">
                      { group.rows.map( ( [ label, value ], i ) => (
                        <div key={ i } className={ cn( 'text-meta flex h-9 items-center justify-between gap-5 text-small', lineTop ) }>
                          <dt>{ label }</dt>
                          <dd className="m-0 text-right">{ value }</dd>
                        </div>
                      ) ) }
                    </dl>
                  </AccordionContent>
                </AccordionItem>
              ) ) }
            </Accordion>
          ) }
        </div>
      </div>
    </section>
  );
}
