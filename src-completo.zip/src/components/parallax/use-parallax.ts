import type { RefObject } from 'react';
import { useEffect, useRef } from 'react';

const noCleanup = (): void => undefined;

export function useParallax( ref: RefObject<HTMLElement | null>, strength = 0.15 ): void {
  const frameRef = useRef( 0 );

  useEffect( () => {
    const el = ref.current;
    if ( !el || strength === 0 || window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
      return noCleanup;
    }

    let offset = 0;
    const write = () => {
      frameRef.current = 0;
      const top = el.getBoundingClientRect().top - offset;
      offset = -top * strength;
      el.style.transform = `translate3d( 0, ${ offset }px, 0 )`;
    };
    const schedule = () => {
      if ( frameRef.current === 0 ) {
        frameRef.current = requestAnimationFrame( write );
      }
    };

    write();
    window.addEventListener( 'scroll', schedule, { passive: true } );
    window.addEventListener( 'resize', schedule );
    return () => {
      window.removeEventListener( 'scroll', schedule );
      window.removeEventListener( 'resize', schedule );
      cancelAnimationFrame( frameRef.current );
      frameRef.current = 0;
      el.style.transform = '';
    };
  }, [ ref, strength ] );
}
