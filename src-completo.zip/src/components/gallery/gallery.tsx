import type { ReactNode } from 'react';
import { useCallback, useState } from 'react';

import { Reveal } from '@/lib/animations/reveal';
import { cn } from '@/lib/utils';

export interface GallerySlide {
  id: string;
  name: ReactNode;
  media: ReactNode;
}

export type GalleryProps =
  | { layout?: 'pair'; small: [ ReactNode, ReactNode ]; large: ReactNode; className?: string }
  | { layout: 'stepper'; slides: GallerySlide[]; label?: ReactNode; className?: string };

function StepDot( { index, chosen, onChoose }: { index: number; chosen: boolean; onChoose: ( index: number ) => void } ) {
  const onClick = useCallback( () => {
    onChoose( index );
  }, [ index, onChoose ] );
  return (
    <button
      type="button"
      aria-pressed={ chosen }
      aria-label={ `Show piece ${ index + 1 }` }
      onClick={ onClick }
      className={ cn( 'block size-2 cursor-pointer rounded-full border border-current p-0', chosen ? 'bg-current' : 'bg-transparent' ) }
    />
  );
}

function GalleryStepper( { slides, label, className = '' }: { slides: GallerySlide[]; label?: ReactNode; className?: string } ) {
  const [ chosen, setChosen ] = useState( 0 );
  const onChoose = useCallback( ( index: number ) => {
    setChosen( index );
  }, [] );
  const fade = 'transition-opacity duration-[400ms] [transition-timing-function:var(--site-ease)] motion-reduce:transition-none';

  return (
    <section data-header="solid" className={ cn( 'bg-background text-foreground', className ) }>
      { label && <p className="text-meta frame-rule m-0 px-[var(--grid-margin)] py-7 text-center text-small">{ label }</p> }
      <Reveal className="frame-rule flex flex-col-reverse lg:grid lg:grid-cols-12">
        <div className="flex flex-col items-center justify-end gap-4 px-[var(--grid-margin)] py-10 text-center lg:col-span-4" aria-live="polite">
          <p className="type-heading m-0 text-h3">{ slides[chosen]?.name }</p>
          { slides.length > 1 && (
            <div className="flex gap-2" role="group" aria-label="Pieces">
              { slides.map( ( slide, i ) => <StepDot key={ slide.id } index={ i } chosen={ i === chosen } onChoose={ onChoose } /> ) }
            </div>
          ) }
        </div>
        <div className="relative aspect-[4/3] overflow-hidden lg:col-span-8 [&_img]:absolute [&_img]:inset-0 [&_img]:h-full [&_img]:w-full [&_img]:object-cover">
          { slides.map( ( slide, i ) => (
            <div key={ slide.id } aria-hidden={ i === chosen ? undefined : 'true' } className={ cn( 'absolute inset-0', fade, i === chosen ? 'opacity-100' : 'opacity-0' ) }>
              { slide.media }
            </div>
          ) ) }
        </div>
      </Reveal>
    </section>
  );
}

const frameClass = 'relative aspect-[3/4] overflow-hidden [&>img]:absolute [&>img]:inset-0 [&>img]:h-full [&>img]:w-full [&>img]:object-cover';

export function Gallery( props: GalleryProps ) {
  if ( props.layout === 'stepper' ) {
    return <GalleryStepper slides={ props.slides } label={ props.label } className={ props.className } />;
  }
  return <GalleryPair small={ props.small } large={ props.large } className={ props.className } />;
}

function GalleryPair( { small, large, className = '' }: { small: [ ReactNode, ReactNode ]; large: ReactNode; className?: string } ) {
  return (
    <section data-header="solid" className={ cn( 'bg-background text-foreground', className ) }>
      <Reveal>
      <div className="grid grid-cols-1 gap-5 px-[var(--grid-margin)] py-[3.75rem] lg:grid-cols-2 lg:gap-[var(--grid-gutter)]">
        <div className="order-first">
          <div className="flex gap-5 lg:sticky lg:top-16 lg:gap-[var(--grid-gutter)]">
            { small.map( ( node, i ) => (
              <div key={ i } className={ cn( frameClass, 'flex-1 lg:w-[calc(var(--col)*2_-_var(--grid-gutter))] lg:flex-none' ) }>{ node }</div>
            ) ) }
          </div>
        </div>
        <div className={ cn( frameClass, 'order-last' ) }>{ large }</div>
      </div>
      </Reveal>
    </section>
  );
}
