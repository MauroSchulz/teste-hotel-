import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <h1 className=" font-semibold tracking-tight">404</h1>
        <p className="mt-2 text-sm text-muted-foreground">Page not found</p>
        <Link to="/" className="mt-4 inline-block text-sm text-primary underline underline-offset-4">
          Go home
        </Link>
      </div>
    </div>
  );
}
