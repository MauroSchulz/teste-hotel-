import reBedroomImage from "@/assets/real-estate/re-bedroom.webp";
import reBlueHouseImage from "@/assets/real-estate/re-blue-house.webp";
import reBrickTerraceImage from "@/assets/real-estate/re-brick-terrace.webp";
import reFtAgentImage from "@/assets/real-estate/re-ft-agent.webp";
import reFtBlockImage from "@/assets/real-estate/re-ft-block.webp";
import reFtSignImage from "@/assets/real-estate/re-ft-sign.webp";
import reGardenHouseImage from "@/assets/real-estate/re-garden-house.webp";
import reHarbourFlatsImage from "@/assets/real-estate/re-harbour-flats.webp";
import reKeysImage from "@/assets/real-estate/re-keys.webp";
import reKitchenImage from "@/assets/real-estate/re-kitchen.webp";
import reLivingRoomImage from "@/assets/real-estate/re-living-room.webp";
import reModernWhiteImage from "@/assets/real-estate/re-modern-white.webp";
import reMovingInImage from "@/assets/real-estate/re-moving-in.webp";
import reShootChapelImage from "@/assets/real-estate/re-shoot-chapel.webp";
import reShootCustomImage from "@/assets/real-estate/re-shoot-custom.webp";
import reShootElmImage from "@/assets/real-estate/re-shoot-elm.webp";
import reShootFerryImage from "@/assets/real-estate/re-shoot-ferry.webp";
import reShootHeronImage from "@/assets/real-estate/re-shoot-heron.webp";
import reShootLindenImage from "@/assets/real-estate/re-shoot-linden.webp";
import reShootMillImage from "@/assets/real-estate/re-shoot-mill.webp";
import reShootOrchardImage from "@/assets/real-estate/re-shoot-orchard.webp";
import reShootParkImage from "@/assets/real-estate/re-shoot-park.webp";
import reShootQuayImage from "@/assets/real-estate/re-shoot-quay.webp";
import reShootRopeImage from "@/assets/real-estate/re-shoot-rope.webp";
import reShootSailImage from "@/assets/real-estate/re-shoot-sail.webp";
import reShootWharfImage from "@/assets/real-estate/re-shoot-wharf.webp";
import reShoreCottageImage from "@/assets/real-estate/re-shore-cottage.webp";
import reStaircaseImage from "@/assets/real-estate/re-staircase.webp";
import reTownhouseImage from "@/assets/real-estate/re-townhouse.webp";
import reWhiteCottageImage from "@/assets/real-estate/re-white-cottage.webp";
import rlBedroomImage from "@/assets/real-estate/rl-bedroom.webp";
import rlBookshelfImage from "@/assets/real-estate/rl-bookshelf.webp";
import rlBrickLoftImage from "@/assets/real-estate/rl-brick-loft.webp";
import rlHallwayImage from "@/assets/real-estate/rl-hallway.webp";
import rlKitchenImage from "@/assets/real-estate/rl-kitchen.webp";
import rlSunnyRoomImage from "@/assets/real-estate/rl-sunny-room.webp";
import homeFilm from "@/assets/real-estate/home-film.mp4";
import homeFilmPoster from "@/assets/real-estate/home-film-poster.webp";

export interface SitePhoto {
  src: string;
  alt: string;
  page?: string;
}

export interface SiteVideo {
  src: string;
  poster: string;
  page?: string;
}

export const home = {
  reBedroom: { src: reBedroomImage, alt: "A sunny bedroom with a blue throw and a potted plant" },
  reBlueHouse: { src: reBlueHouseImage, alt: "A grey-blue gabled house behind a striped lawn" },
  reBrickTerrace: { src: reBrickTerraceImage, alt: "A red brick terraced house with a black front door" },
  reFtAgent: { src: reFtAgentImage, alt: "An agent in a suit on a quiet street" },
  reFtBlock: { src: reFtBlockImage, alt: "White apartment buildings in the sun" },
  reFtSign: { src: reFtSignImage, alt: "An agent standing by a for-sale sign" },
  reGardenHouse: { src: reGardenHouseImage, alt: "A white house with a long lawn in front" },
  reHarbourFlats: { src: reHarbourFlatsImage, alt: "Modern flats with glass balconies against a blue sky" },
  reKeys: { src: reKeysImage, alt: "Keys being handed over across a table" },
  reKitchen: { src: reKitchenImage, alt: "A white kitchen with marble splashback and brass tap" },
  reLivingRoom: { src: reLivingRoomImage, alt: "A bright living room with a grey sofa and framed prints" },
  reModernWhite: { src: reModernWhiteImage, alt: "A white modern house with a lawn and a pine tree" },
  reMovingIn: { src: reMovingInImage, alt: "A couple carrying moving boxes in their new hallway" },
  reShootChapel: { src: reShootChapelImage, alt: "A white thatched cottage behind a garden path" },
  reShootCustom: { src: reShootCustomImage, alt: "A pale townhouse with a blue door, a bench and planters" },
  reShootElm: { src: reShootElmImage, alt: "A stone house with pink blossom in the front garden" },
  reShootFerry: { src: reShootFerryImage, alt: "A wide stone house covered in ivy" },
  reShootHeron: { src: reShootHeronImage, alt: "A townhouse with a pale blue door and two rows of tall windows" },
  reShootLinden: { src: reShootLindenImage, alt: "A detached stone house above a long lawn" },
  reShootMill: { src: reShootMillImage, alt: "A street of stone cottages leading to a church spire" },
  reShootOrchard: { src: reShootOrchardImage, alt: "A brick cottage behind a wooden fence" },
  reShootPark: { src: reShootParkImage, alt: "Old village houses with a sunny stone front" },
  reShootQuay: { src: reShootQuayImage, alt: "A white terraced townhouse with black railings and a short flight of steps" },
  reShootRope: { src: reShootRopeImage, alt: "A small stone cottage with green window frames" },
  reShootSail: { src: reShootSailImage, alt: "A blue-painted cottage on a quiet road with a mossy roof" },
  reShootWharf: { src: reShootWharfImage, alt: "A white Georgian house with a red door behind a small front garden" },
  reShoreCottage: { src: reShoreCottageImage, alt: "A turf-roofed cottage on a green slope above the water" },
  reStaircase: { src: reStaircaseImage, alt: "A spiral staircase seen from below, lit warm" },
  reTownhouse: { src: reTownhouseImage, alt: "A dark painted townhouse with white window frames and railings" },
  reWhiteCottage: { src: reWhiteCottageImage, alt: "A white cottage with a picket fence under autumn trees" },
  rlBedroom: { src: rlBedroomImage, alt: "A bright bedroom with plants and white pillows" },
  rlBookshelf: { src: rlBookshelfImage, alt: "An armchair and bookshelves against a brick wall" },
  rlBrickLoft: { src: rlBrickLoftImage, alt: "A brick-walled loft with a red daybed" },
  rlHallway: { src: rlHallwayImage, alt: "A long white hallway under a brass ceiling light" },
  rlKitchen: { src: rlKitchenImage, alt: "A light Scandinavian kitchen with wooden details" },
  rlSunnyRoom: { src: rlSunnyRoomImage, alt: "A living room with tall windows and afternoon sun on the floor" },
} satisfies Record<string, SitePhoto>;

export const videos = {
  agentHome: { src: homeFilm, poster: homeFilmPoster },
} satisfies Record<string, SiteVideo>;
