import { Link } from "react-router-dom";
import { TextLink } from "@/components/base/text-link";
import { Button } from "@/components/ui/button";
import { CollectionIndex } from "@/components/collection-index/collection-index";
import { ContactDetails } from "@/components/contact-details/contact-details";
import { ContactDetailsForm } from "@/components/contact-details/contact-details-form";
import { FullMedia } from "@/components/full-media/full-media";
import { Gallery } from "@/components/gallery/gallery";
import { HomesIndex } from "@/components/homes-index/homes-index";
import { PostHeader } from "@/components/post-header/post-header";
import { ProductDetail } from "@/components/product-detail/product-detail";
import { ProductRow } from "@/components/product-row/product-row";
import { StatementSection } from "@/components/statement-section/statement-section";
import { StoryHighlight } from "@/components/story-highlight/story-highlight";
import { TextMedia } from "@/components/text-media/text-media";
import { HeroVideo, VideoHero } from "@/components/video-hero/video-hero";
import { lindqvist } from "@/style-packs/lindqvist";

import type { SitePhoto } from "./media";
import { home as h, videos } from "./media";
import type { SiteDef } from "./parts";
import { Img, Wordmark } from "./parts";

const areaNames: Record<string, string> = { harbourside: "Harbourside", "old-town": "Old Town", northside: "Northside" };

const agentHomes: Array<{ id: string; area: string; name: string; status?: string; beds: number; baths: number; outside: string; price: string; band: string; energy: string; about: string; photo: SitePhoto; inside?: SitePhoto; rooms: SitePhoto[] }> = [
  { id: "heron", area: "harbourside", name: "5 Heron Close", status: "Just listed", beds: 4, baths: 2, outside: "Garden and garage", price: "£790,000", band: "F", energy: "C", about: "A family house on a quiet close, with a garden that catches the evening sun. Two minutes to the harbour primary school.", photo: h.reShootHeron, inside: h.reBedroom, rooms: [ h.reBedroom, h.reStaircase, h.reKitchen ] },
  { id: "quay", area: "harbourside", name: "14 Quay Street", beds: 3, baths: 2, outside: "Walled garden", price: "£640,000", band: "E", energy: "C", about: "A Georgian townhouse on the quay, with the harbour at the end of the street. The kitchen opens onto a walled garden that gets the afternoon sun.", photo: h.reShootQuay, inside: h.reLivingRoom, rooms: [ h.reLivingRoom, h.reKitchen, h.reBedroom ] },
  { id: "wharf", area: "harbourside", name: "Flat 2, Harbour Wharf", status: "Under offer", beds: 2, baths: 1, outside: "Balcony over the water", price: "£385,000", band: "C", energy: "B", about: "A second-floor flat in a converted grain store, with a balcony over the water. Lift, bike store and one parking space.", photo: h.reShootWharf, rooms: [ h.rlSunnyRoom, h.rlKitchen ] },
  { id: "sail", area: "harbourside", name: "3 Sail Loft Lane", beds: 2, baths: 1, outside: "Sea view", price: "£455,000", band: "C", energy: "D", about: "An old net loft on the edge of town, turned into a two-bedroom cottage. Every room looks at the sea.", photo: h.reShootSail, rooms: [ h.rlBookshelf, h.rlBedroom ] },
  { id: "orchard", area: "old-town", name: "7 Orchard Row", beds: 2, baths: 1, outside: "Courtyard", price: "£415,000", band: "C", energy: "D", about: "A brick terrace behind the church, five minutes from the station. A small courtyard, and a loft that could be a third bedroom.", photo: h.reShootOrchard, inside: h.reKitchen, rooms: [ h.reKitchen, h.rlHallway ] },
  { id: "chapel", area: "old-town", name: "12 Chapel Walk", beds: 3, baths: 1, outside: "Front and back garden", price: "£520,000", band: "D", energy: "D", about: "A white weatherboard cottage on a lane with no through traffic. The back garden runs down to the old orchard wall.", photo: h.reShootChapel, rooms: [ h.rlSunnyRoom, h.rlBedroom ] },
  { id: "ferry", area: "old-town", name: "22 Ferry Lane", beds: 4, baths: 3, outside: "Garden and parking", price: "£825,000", band: "F", energy: "C", about: "A double-fronted house at the top of Ferry Lane, with tall ceilings and a garden big enough for a vegetable patch.", photo: h.reShootFerry, rooms: [ h.reLivingRoom, h.reStaircase ] },
  { id: "linden", area: "northside", name: "9 Linden Avenue", beds: 5, baths: 3, outside: "Large garden", price: "£895,000", band: "G", energy: "C", about: "The largest house I have for sale: five bedrooms, a long lawn and the park at the end of the road.", photo: h.reShootLinden, rooms: [ h.rlKitchen, h.rlBedroom, h.rlBookshelf ] },
  { id: "elm", area: "northside", name: "31 Elm Rise", beds: 4, baths: 2, outside: "Garden", price: "£760,000", band: "F", energy: "B", about: "A gabled family house, rebuilt inside three years ago, with a new kitchen and a garden room.", photo: h.reShootElm, rooms: [ h.rlHallway, h.rlSunnyRoom ] },
  { id: "custom", area: "harbourside", name: "Flat 6, Custom House", status: "Sold", beds: 2, baths: 2, outside: "Roof terrace", price: "£430,000", band: "D", energy: "B", about: "A top-floor flat in the old customs building, with a roof terrace over the harbour. Sold in four weeks.", photo: h.reShootCustom, rooms: [ h.rlSunnyRoom ] },
  { id: "mill", area: "old-town", name: "2 Mill Yard", status: "Sold", beds: 2, baths: 1, outside: "Courtyard", price: "£450,000", band: "C", energy: "C", about: "A converted mill workers' house off Church Lane. Sold over the asking price.", photo: h.reShootMill, rooms: [ h.rlBrickLoft ] },
  { id: "rope", area: "harbourside", name: "18 Rope Walk", status: "Sold", beds: 3, baths: 1, outside: "Yard", price: "£520,000", band: "D", energy: "D", about: "A fisherman's cottage two streets from the quay. Sold to a family moving from the city.", photo: h.reShootRope, rooms: [ h.rlBookshelf ] },
  { id: "park", area: "northside", name: "40 Park Road", status: "Sold", beds: 4, baths: 2, outside: "Garden", price: "£705,000", band: "E", energy: "C", about: "A family house by the park. Sold before it reached the website.", photo: h.reShootPark, rooms: [ h.rlKitchen ] }
];

const agentStories: Array<{ id: string; filter: string; kicker: string; title: string; lede: string; body: string[]; quote: string; photo: SitePhoto; more: [ SitePhoto, SitePhoto ] }> = [
  { id: "first-flat", filter: "selling", kicker: "Selling", title: "Selling our first flat: Priya and Tom", lede: "They had a baby due and eight weeks to move. This is how we sold the flat in five and found the house in four.", body: [ "Priya called on a Monday. By Thursday the flat was photographed, and by the next Saturday six couples had seen it.", "The offer they took was not the highest. It came from a buyer with no chain, and that bought them the weeks they needed." ], quote: "We stopped checking the website. Mara just rang when something happened.", photo: h.reMovingIn, more: [ h.reKeys, h.reLivingRoom ] },
  { id: "ready", filter: "selling", kicker: "Selling", title: "Five things to fix before the photographs, and five to leave", lede: "Most of what sellers fix before the photographs makes no difference to the price. A few things do.", body: [ "Fix the light bulbs, the dripping tap and the door that sticks. Buyers notice small faults and wonder what else is wrong.", "Leave the kitchen. Nobody pays more for new cupboard doors, and most buyers plan to change it anyway." ], quote: "Clear the hallway. It is the first photograph and the first thing anyone sees.", photo: h.reLivingRoom, more: [ h.reStaircase, h.reKitchen ] },
  { id: "before-listed", filter: "buying", kicker: "Buying", title: "How the best homes sell before they are listed", lede: "About a third of the homes I sell never reach a website. Here is how buyers hear about them first.", body: [ "When someone asks me to value their home, I already know who has been looking for one like it.", "Tell me what you want, and what you would give up to get it. The second part matters more." ], quote: "The buyers who get the good homes are the ones who told me exactly what they wanted.", photo: h.reKeys, more: [ h.reTownhouse, h.reWhiteCottage ] },
  { id: "survey", filter: "buying", kicker: "Buying", title: "What a survey on an old harbour cottage tends to find", lede: "Salt air, old lime walls and a century of quick repairs. None of it needs to put you off.", body: [ "Damp in a harbour cottage is usually the walls breathing, not a leak. Lime plaster lets it out; modern paint traps it in.", "Ask the surveyor what needs doing in the first year, and what can wait five. Then ask me for a builder who knows old houses." ], quote: "Every old cottage has a list. The question is whether it is a short one.", photo: h.reStaircase, more: [ h.reShoreCottage, h.rlBookshelf ] },
  { id: "autumn", filter: "market", kicker: "The market", title: "The autumn market, street by street", lede: "Prices in Old Town held while Harbourside cooled. Every sale I made this quarter, and what it went for.", body: [ "Eleven homes sold between September and November. Old Town homes went for 2% over the asking price on average; Harbourside for 3% under.", "Family houses in Northside sold fastest, in a little over four weeks." ], quote: "Harbourside did not fall. It came back to where it was two years ago.", photo: h.reFtSign, more: [ h.reBrickTerrace, h.reGardenHouse ] },
  { id: "summer", filter: "market", kicker: "The market", title: "Summer: Old Town held while Harbourside cooled", lede: "A quiet summer everywhere but the lanes around the church.", body: [ "Seven homes sold between June and August, fewer than last year, as buyers waited for rates to settle.", "Old Town was the exception: three homes, all over the asking price." ], quote: "Small houses near the station never stay quiet for long.", photo: h.reKitchen, more: [ h.reHarbourFlats, h.reBlueHouse ] }
];

const agentForSale = agentHomes.filter( home => home.status !== "Sold" );
const priceOf = ( price: string ) => Number( price.replace( /[^\d]/g, "" ) );
const homeHref = ( id: string ) => `/homes/${ id }`;
const postHref = ( id: string ) => `/blog/${ id }`;
export const site: SiteDef = {
    pack: lindqvist,
    layout: "margin",
    header: {
      name: "Mara Lindqvist",
      home: "/",
      start: [ { label: "Homes", href: `/homes` }, { label: "About", href: `/about` }, { label: "Blog", href: `/blog` } ],
      end: [ { label: "Contact", href: `/contact` } ]
    },
    hero: (
      <VideoHero
        src={ videos.agentHome.src }
        poster={ videos.agentHome.poster }
        title="Mara Lindqvist, estate agent in Harbourside"
        wordmark={ <Wordmark lines={ [ "Mara", "Lindqvist" ] } tag="Estate agent" /> }
        caption={
          <TextLink href={ `/homes` } className="flex flex-wrap gap-x-6 gap-y-1 pb-1 text-large">
            <span className="opacity-75">Featured</span>
            <span>14 Quay Street</span>
            <span>£640,000</span>
            <span aria-hidden="true">→</span>
          </TextLink>
        }
      />
    ),
    footer: {
      contact: { label: "Contact", text: "Questions about a home, or ready to sell? Mara answers every message herself, usually the same day.", action: <TextLink href={ `/contact` }>Book a valuation</TextLink> },
      address: { label: "Office / Harbourside", lines: [ "Mara Lindqvist Estate Agents", "14 Dock Street, Harbourside", "HB1 4QT" ], action: <TextLink href="mailto:mara@lindqvist.example">mara@lindqvist.example</TextLink> },
      photos: [ <Img key="0" photo={ h.reFtSign } />, <Img key="1" photo={ h.reFtAgent } />, <Img key="2" photo={ h.reFtBlock } /> ],
      social: <>{ [ [ "X", "https://twitter.com/Lovable" ], [ "Discord", "https://discord.com/invite/lovable-dev" ], [ "Reddit", "https://reddit.com/r/lovable" ], [ "YouTube", "https://www.youtube.com/@lovable" ], [ "LinkedIn", "https://www.linkedin.com/company/lovable-dev/" ] ].map( ( [ label, href ] ) => <TextLink key={ href } href={ href }>{ label }</TextLink> ) }</>,
      copyright: "© Mara Lindqvist Estate Agents, 2026"
    },
    after: (
      <>
        <TextMedia label={ <>Valued in person.<br />Sold in weeks.</> } media={ <Img photo={ h.reKeys } /> } action={ <TextLink href={ `/contact` }>Book a valuation</TextLink> }>
          <p className="m-0">A valuation is an hour in your home, not a figure from a website. You get a written price the same week, with the three recent sales it is based on.</p>
          <p className="m-0">Most homes I list sell within six weeks. The fee is 1.2% plus VAT, and nothing if it does not sell. Call me on 01632 960318.</p>
        </TextMedia>
        <StatementSection eyebrow="Harbourside, since 2014" action={ <TextLink href={ `/about` }>About Mara</TextLink> }>
          Twelve years selling homes on the harbour side of town — every one visited, photographed and shown by me, not an assistant.
        </StatementSection>
        <ProductRow
          title="Homes for sale"
          action={ <TextLink href={ `/homes` }>All { agentForSale.length } homes</TextLink> }
          items={ [ "quay", "orchard", "heron" ].map( id => agentHomes.find( home => home.id === id )! ).map( home => ( {
            id: home.id,
            href: homeHref( home.id ),
            name: home.name,
            detail: `${ home.beds } bedrooms · ${ home.price }`,
            image: <Img photo={ home.photo } />,
            hoverImage: home.inside ? <Img photo={ home.inside } /> : undefined
          } ) ) }
        />
        <StoryHighlight
          ground="#e9dfd1"
          ink="#161614"
          title="Selling our first flat: Priya and Tom"
          lede="They had a baby due and eight weeks to move. This is how we sold the flat in five and found the house in four."
          action={ <TextLink href={ postHref( "first-flat" ) }>Read the story</TextLink> }
          media={ <Img photo={ h.reMovingIn } /> }
        />
      </>
    ),
    items: {
      homes: id => {
        const home = agentHomes.find( one => one.id === id );
        if ( !home ) {
          return undefined;
        }
        const nearby = agentForSale.filter( one => one.area === home.area && one.id !== home.id ).slice( 0, 3 );
        return {
          title: home.name,
          content: (
            <>
              <ProductDetail
                photos={ [ home.photo, ...home.rooms ].map( photo => <Img key={ photo.src } photo={ photo } /> ) }
                title={ home.name }
                price={ home.price }
                description={ home.about }
                features={ [ `${ home.beds } bedrooms`, `${ home.baths } ${ home.baths === 1 ? "bathroom" : "bathrooms" }`, home.outside, "Freehold" ] }
                note={ `Council tax band ${ home.band }. Energy rating ${ home.energy }.` }
                actions={ [
                  <Button asChild key="view"><Link to={ `/contact` }>Book a viewing</Link></Button>,
                  <Button asChild key="call" variant="outline"><a href="tel:+441632960318">Call Mara</a></Button>
                ] }
                details={ [
                  { id: "rooms", title: "Rooms and sizes", rows: [ [ "Living room", "5.2 × 4.1 m" ], [ "Kitchen", "4.4 × 3.6 m" ], ...Array.from( { length: home.beds }, ( _, i ): [ string, string ] => [ `Bedroom ${ i + 1 }`, i === 0 ? "4.0 × 3.6 m" : "3.4 × 2.9 m" ] ) ] },
                  { id: "costs", title: "Costs", rows: [ [ "Council tax", `Band ${ home.band }` ], [ "Energy rating", home.energy ], [ "Tenure", "Freehold" ] ] }
                ] }
              />
              { nearby.length > 0 && (
                <ProductRow
                  title={ `More in ${ areaNames[home.area] }` }
                  action={ <TextLink href={ `/homes` }>All homes</TextLink> }
                  items={ nearby.map( one => ( { id: one.id, href: homeHref( one.id ), name: one.name, detail: `${ one.beds } bedrooms · ${ one.price }`, image: <Img photo={ one.photo } /> } ) ) }
                />
              ) }
            </>
          )
        };
      },
      blog: id => {
        const index = agentStories.findIndex( one => one.id === id );
        if ( index === -1 ) {
          return undefined;
        }
        const story = agentStories[index];
        const next = agentStories[( index + 1 ) % agentStories.length];
        return {
          title: story.title,
          content: (
            <>
              <PostHeader kicker={ story.kicker } title={ story.title } lede={ story.lede } media={ <Img photo={ story.photo } /> } />
              <TextMedia label="What happened" media={ <Img photo={ story.more[0] } /> }>
                { story.body.map( paragraph => <p key={ paragraph } className="m-0">{ paragraph }</p> ) }
              </TextMedia>
              <StatementSection>“{ story.quote }”</StatementSection>
              <Gallery small={ [ <Img key="a" photo={ story.more[0] } />, <Img key="b" photo={ story.more[1] } /> ] } large={ <Img photo={ story.photo } /> } />
              <StoryHighlight
                ground="#e9dfd1"
                ink="#161614"
                title={ next.title }
                lede={ next.lede }
                action={ <TextLink href={ postHref( next.id ) }>Read the next story</TextLink> }
                media={ <Img photo={ next.photo } /> }
              />
            </>
          )
        };
      }
    },
    pages: {
      homes: {
        title: "Homes for sale",
        content: (
          <HomesIndex
            title="Homes for sale"
            ground="#e9dfd1"
            ink="#161614"
            areas={ [
              { id: "all", label: "All homes", text: "Every home I have for sale, in the three neighbourhoods I know street by street. Each one I have visited, photographed and will show you myself." },
              { id: "harbourside", label: "Harbourside", text: "Warehouse flats and fishermen's cottages, most of them a minute from the water." },
              { id: "old-town", label: "Old Town", text: "Brick terraces and narrow lanes around the church, a short walk from the station." },
              { id: "northside", label: "Northside", text: "Family houses with gardens, near the park and the two primary schools." }
            ] }
            sold={ { label: "Recently sold", text: "What sold this season, and what it went for. Most went within six weeks." } }
            homes={ agentHomes.map( home => ( {
              id: home.id,
              area: home.area,
              href: homeHref( home.id ),
              name: home.name,
              status: home.status,
              price: priceOf( home.price ),
              facts: `${ home.beds } bedrooms · ${ home.outside.toLowerCase() }`,
              image: <Img photo={ home.photo } />
            } ) ) }
          />
        )
      },
      about: {
        title: "About Mara",
        content: (
          <div className="pt-[var(--site-header-height)]">
            <h1 className="sr-only">About Mara</h1>
            <StatementSection>
              I sell homes in the three neighbourhoods I have lived in, and I show every one of them myself.
            </StatementSection>
            <FullMedia media={ <HeroVideo src={ videos.agentHome.src } poster={ videos.agentHome.poster } /> } />
            <TextMedia label="Harbourside, since 2014" media={ <Img photo={ h.reFtAgent } /> }>
              <p className="m-0">I started on my own after eight years at a big agency, where I sold homes I had never been inside.</p>
              <p className="m-0">Now I take on fewer homes, and I know each one well enough to answer any question about it.</p>
            </TextMedia>
            <StatementSection>
              A sale takes about six weeks. You will know what is happening in every one of them.
            </StatementSection>
            <TextMedia label="How a sale works" media={ <Img photo={ h.reKeys } /> } action={ <TextLink href={ `/contact` }>Book a valuation</TextLink> }>
              <h3 className="m-0 text-h4">The valuation</h3>
              <p className="m-0">An hour in your home, and a written price the same week.</p>
              <h3 className="m-0 mt-4 text-h4">The photographs</h3>
              <p className="m-0">I take them myself, on a bright morning, and you see them first.</p>
              <h3 className="m-0 mt-4 text-h4">The viewings</h3>
              <p className="m-0">I show every buyer round. You never have to.</p>
              <h3 className="m-0 mt-4 text-h4">The offer</h3>
              <p className="m-0">I tell you every offer the day it comes in, and what I think of it.</p>
            </TextMedia>
            <Gallery small={ [ <Img key="a" photo={ h.reWhiteCottage } />, <Img key="b" photo={ h.reModernWhite } /> ] } large={ <Img photo={ h.reGardenHouse } /> } />
          </div>
        )
      },
      contact: {
        title: "Contact",
        content: (
          <>
            <ContactDetails
              title="Talk to Mara"
              media={ <Img photo={ h.reFtAgent } /> }
              rows={ [
                {
                  id: "sell",
                  label: "Selling your home",
                  content: (
                    <>
                      <p>Tell me a little about your home and when you would like to move. I will come round for an hour and give you a written price the same week.</p>
                      <TextLink href="mailto:mara@lindqvist.example">mara@lindqvist.example</TextLink>
                    </>
                  )
                },
                {
                  id: "buy",
                  label: "Buying",
                  content: (
                    <>
                      <p>Looking in Harbourside, Old Town or Northside? I often hear about a home before it is listed.</p>
                      <p>You can also fill in the form below.</p>
                      <ContactDetailsForm subject="Buying" />
                      <p>Prefer to talk? <TextLink href="tel:+441632960318">01632 960318</TextLink><br />Monday to Saturday, 9:00 to 18:00</p>
                    </>
                  )
                },
                {
                  id: "press",
                  label: "Press",
                  content: (
                    <>
                      <p>For the quarterly market figures, or a comment on the local market.</p>
                      <TextLink href="mailto:press@lindqvist.example">press@lindqvist.example</TextLink>
                    </>
                  )
                }
              ] }
            />
            <FullMedia
              media={ <Img photo={ h.reFtBlock } /> }
              label={ <>14 Dock Street<br />/ Harbourside</> }
              text="The office is on the corner by the harbour steps. Come in for a coffee, no appointment needed."
              href={ `/about` }
              actionLabel="About Mara"
            />
          </>
        )
      },
      blog: {
        title: "Blog",
        content: (
          <CollectionIndex
            title="Blog"
            filters={ [
              { id: "all", label: "All stories", text: "Notes from twelve years of selling homes in Harbourside: what worked, what the market is doing, and the people who moved." },
              { id: "selling", label: "Selling", text: "How to get a home ready, and what to expect in the six weeks after it goes on sale." },
              { id: "buying", label: "Buying", text: "Finding a home in a small town where the best ones rarely reach the websites." },
              { id: "market", label: "The market", text: "Every sale I made this quarter, and what it went for." }
            ] }
            items={ agentStories.map( story => ( {
              id: story.id,
              filter: story.filter,
              href: postHref( story.id ),
              kicker: story.kicker,
              name: story.title,
              image: <Img photo={ story.photo } />
            } ) ) }
          />
        )
      }
    }
};
