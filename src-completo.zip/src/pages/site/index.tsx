import { useLayoutEffect } from "react";
import { useParams } from "react-router-dom";

import NotFound from "@/pages/not-found";

import { site } from "./site";
import { SiteTemplate } from "./parts";

export function SitePage() {
  const { page, item } = useParams();
  const subpage = page === undefined ? undefined : item === undefined ? site.pages[page] : site.items[page]?.( item );

  useLayoutEffect( () => {
    window.scrollTo( 0, 0 );
  }, [ page, item ] );

  if ( page !== undefined && !subpage ) {
    return <NotFound />;
  }
  return (
    <SiteTemplate name="real-estate-agent" pack={ site.pack } layout={ site.layout } header={ site.header } footer={ site.footer }>
      { subpage ? subpage.content : <>{ site.hero }{ site.after }</> }
    </SiteTemplate>
  );
}
