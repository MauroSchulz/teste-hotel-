import "./site.css";

import type { CSSProperties, ReactNode } from "react";
import { useLayoutEffect } from "react";

import type { SiteFooterProps } from "@/components/site-footer/site-footer";
import { SiteFooter } from "@/components/site-footer/site-footer";
import type { SiteHeaderProps } from "@/components/site-header/site-header";
import { SiteHeader } from "@/components/site-header/site-header";
import { cn } from "@/lib/utils";
import { applySitePack } from "@/style-packs";
import type { SitePack } from "@/style-packs/types";

import type { SitePhoto } from "./media";

export interface SiteDef {
  pack: SitePack;
  layout: PageLayout;
  header: SiteHeaderProps;
  footer: SiteFooterProps;
  hero: ReactNode;
  after: ReactNode;
  pages: Record<string, { title: string; content: ReactNode }>;
  items: Record<string, ( id: string ) => { title: string; content: ReactNode } | undefined>;
}

export type PageLayout = "margin";

export function SiteTemplate( { name, pack, header, footer, layout = "margin", children }: {
  name: string;
  pack: SitePack;
  layout?: PageLayout;
  header: SiteHeaderProps;
  footer?: SiteFooterProps;
  children: ReactNode;
} ) {
  useLayoutEffect( () => {
    const root = document.documentElement;
    const before = root.getAttribute( "style" );
    applySitePack( pack );
    return () => {
      if ( before === null ) {
        root.removeAttribute( "style" );
      } else {
        root.setAttribute( "style", before );
      }
    };
  }, [ pack ] );

  return (
    <div className={ cn( "themed-type site-template min-h-screen bg-background text-foreground", `site-template-${ name }`, `layout-${ layout }` ) }>
      <SiteHeader overlay { ...header } />
      <main>{ children }</main>
      { footer && <SiteFooter { ...footer } /> }
    </div>
  );
}

export function Img( { photo, style }: { photo: SitePhoto; style?: CSSProperties } ) {
  return <img src={ photo.src } alt={ photo.alt } style={ style } />;
}

export function Wordmark( { lines, tag }: { lines: string[]; tag?: string } ) {
  const lineHeight = 58;
  const height = ( lines.length * lineHeight ) + ( tag ? 34 : 0 );
  return (
    <svg viewBox={ `0 0 400 ${ height }` } role="img" aria-hidden="true" className="fill-current">
      { lines.map( ( line, i ) => (
        <text
          key={ line }
          x="200"
          y={ ( ( i + 1 ) * lineHeight ) - 8 }
          textAnchor="middle"
          fontSize={ 54 }
          className="type-brand [font-weight:var(--font-heading-weight)] tracking-[0.06em] [font-family:var(--font-heading)]"
        >
          { line }
        </text>
      ) ) }
      { tag && (
        <text x="200" y={ height - 6 } textAnchor="middle" fontSize={ 17 } className="type-brand tracking-[0.3em] [font-family:var(--font-body)]">
          { tag }
        </text>
      ) }
    </svg>
  );
}
