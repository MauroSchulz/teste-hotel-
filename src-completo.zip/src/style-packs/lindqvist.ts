import type { SitePack } from "./types";

export const lindqvist: SitePack = {
  "label": "Lindqvist",
  "previewColor": "#161614",
  "colors": [
    "#161614",
    "#faf8f4",
    "#efebe3",
    "#efebe3"
  ],
  "colorTokens": {
    "primary": "#161614",
    "primaryForeground": "#faf8f4",
    "background": "#faf8f4",
    "foreground": "#161614",
    "secondary": "#efebe3",
    "secondaryForeground": "#161614",
    "accent": "#efebe3",
    "accentForeground": "#161614",
    "muted": "#efebe3",
    "mutedForeground": "color-mix(in srgb, #161614 62%, transparent)",
    "card": "#faf8f4",
    "cardForeground": "#161614",
    "popover": "#faf8f4",
    "popoverForeground": "#161614",
    "destructive": "oklch(0.577 0.245 27.325)",
    "destructiveForeground": "#faf8f4",
    "border": "color-mix(in srgb, #161614 18%, transparent)",
    "input": "color-mix(in srgb, #161614 18%, transparent)",
    "ring": "#161614"
  },
  "font": {
    "heading": {
      "family": "Fraunces",
      "url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;1,300&family=DM+Sans:wght@400;500&display=swap"
    },
    "body": {
      "family": "DM Sans",
      "url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;1,300&family=DM+Sans:wght@400;500&display=swap"
    }
  },
  "typeset": {
    "name": "fraunces-dm-sans",
    "category": "mixed",
    "basePx": 16,
    "maxPageWidth": "1400px",
    "roles": {
      "heading": {
        "family": "Fraunces",
        "url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;1,300&family=DM+Sans:wght@400;500&display=swap",
        "weight": 300,
        "lineHeight": "0.95em",
        "letterSpacing": "-0.02em",
        "textTransform": "none"
      },
      "body": {
        "family": "DM Sans",
        "url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;1,300&family=DM+Sans:wght@400;500&display=swap",
        "weight": 400,
        "lineHeight": "1.4em",
        "letterSpacing": "0em",
        "textTransform": "none"
      },
      "meta": {
        "family": "DM Sans",
        "url": "https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,300;1,300&family=DM+Sans:wght@400;500&display=swap",
        "weight": 500,
        "lineHeight": "1em",
        "letterSpacing": "0.12em",
        "textTransform": "uppercase"
      }
    },
    "scale": {
      "heading1": 6,
      "heading2": 4,
      "heading3": 3.9,
      "heading4": 2.2,
      "largeText": 1.5,
      "smallText": 0.9
    }
  },
};

export default lindqvist;
